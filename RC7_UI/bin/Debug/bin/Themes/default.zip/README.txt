README
 * GUIDE: CUSTOM THEMES FOR RC7
 * All Files requried to be in .bmp format
 * Gfx must be placed in C:\RC7_THEMES
 * Your gfx must correspond to one of the names below or it wont work 
 * You can download themes at https://goo.gl/ircaoJ 
 - - - - - - - - - - - - - - - - - - - - - - - -
 (Gfx -> Filename)
 *RC7 background -> MainUi.bmp
 *Buttons IDLE -> S_Button_Idle.bmp
 *Buttons HOVER -> S_Button_Hover.bmp
 *Buttons CLICKED -> S_Button_Clicked.bmp
 *AutoRun CLICKED -> Auto_In.bmp
 *WordWrap CLICKED -> WordWrap_In.bmp
 *Wolf CLICKED -> Wolfy_In.bmp
 *Ro-Xploit CLICKED -> Krystal_In.bmp
 *Google Drive CLICKED -> Google_Drive_In.bmp
 *Save Button CLICKED -> Save_In.bmp
 *TextBox -> TextBox.bmp
 *Hide_Side -> Hide_Side.bmp
 *Login button IDLE -> Button_Idle.bmp
 *Login button HOVER -> Button_Hover.bmp
 *Login button CLICKED -> Button_Clicked.bmp
 *Custom Sounds: *Place any .wav file in RC7_THEMES directory